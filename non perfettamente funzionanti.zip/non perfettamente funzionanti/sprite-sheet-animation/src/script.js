$(document).ready(function(){
  $(".navbar-toggler").click(function(){
    $(".navbar-toggler").toggleClass("nav_btn")
  })
});
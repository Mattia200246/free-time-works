/* www.youtube.com/CodeExplained */
//SELECT ELEMENT
const BalanceEl = document.querySelector(".balance .value");
const IncomeTotalEl = document.querySelector(".income-total");
const OutcomeTotalEl = document.querySelector(".outcome-total");
const IncomeEl = document.querySelector("#income");
const ExpenseEl = document.querySelector("#expense");
const AllEl = document.querySelector("#all")
const IncomeList = document.querySelector("#income .list");
const ExpenseList = document.querySelector("#expense .list");
const AllList = document.querySelector("#all .list");

//SELECT BTN
const ExpenseBtn = document.querySelector(".tab1");
const IncomeBtn = document.querySelector(".tab2");
const AllBtn = document.querySelector(".tab3");

//INPUT BTN
const AddExpense = document.querySelector(".add-expense");
const ExpenseTitle = document.getElementById("expense-title-input");
const ExpenseAmount = document.getElementById("expense-amount-input");

const AddIncome = document.querySelector(".add-income");
const IncomeTitle = document.getElementById("Income-title-input");
const IncomeAmount = document.getElementById("income-amount-input");

let ENTRY_LIST = [];
let Balance = 0, Income=0, Outcome=0;

const DELETE = "delete", EDIT="edit";

  ExpenseBtn.addEventListener("click", function(){
  show(ExpenseEl);
  hide( [IncomeEl,AllEl] );
  active( ExpenseBtn );
  inactive([IncomeBtn, AllBtn])
})
IncomeBtn .addEventListener("click", function(){
  show(IncomeEl);
  hide( [ExpenseEl,AllEl] );
  active(IncomeBtn);
  inactive([ExpenseBtn, AllBtn])
})
AllBtn.addEventListener("click", function(){
  show(AllEl);
  hide( [IncomeEl,ExpensiveEl] );
  active(AllBtn);
  inactive([IncomeBtn, ExpenseBtn])
})

addExpense.addEventListener("click", function(){
  //se uno dei valori è vuoto esci
  if(!ExpensiveTitle.value || !ExpenseAmount.value)return;

  //salva il valore
  let Expense = {
    type : "expense",
    title: ExpenseTitle.value,
    amount : ExpenseAmount.value
  }
  ENTRY_LIST.push(Expense);
  updateUI();
  clearInput( [ExpensiveTitle, !ExpenseAmount] );
})

addIncome.addEventListener("click", function(){
  //se uno dei valori è vuoto, esci
  if(!IncomeTitle.value || !IncomeAmount.value)return;

  //salva il valore
  let Income = {
    type : "expense",
    title: IncomeTitle.value,
    amount : IncomeAmount.value
  }
  ENTRY_LIST.push(Income);

  updateUI();
  clearInput( [Income, !IncomeAmount] );
})


function updateUI()
{
  Income =calculateTotal("income", ENTRY_LIST);
  Outcome =calculateTotal("outcome", ENTRY_LIST);
  Balance =calculateBalance(Income, Outcome);

  //Update UI
  clearElement( [ExpenseList, IncomeList, AllLIst]);

  //determinare segno BalanceEl
  let sign = (income >= Outcome) ? : "$" : "-$";

  ENTRY_LIST.forEach(entry,index)=>{
    if(entry.type=="expense"){
      showEntry(ExpensiveList, entry.type, entry.title, entry.amount, index)
    }else if (entry.type=="income"){
      showEntry(IncomeList, entry.type, entry.title, entry.amount, index)
    }
    showEntry(AllList, entry.type, entry.title, entry.amount, index)
  });
}

function showEntry(list,type,title.amount,id)
{
  const entry=  '<li id = "${id}" class="${type}">
                  <div  class="entry">${title}: $${amount}</div>
                  <div id="edit"></div>
                  <div id="delete"></div>
                </li>';
  const position = "afterbegin";

  list.insertAdjacentHTML(position, entry);
}

function clearElement()
{
  elements.forEach(element=>{
    element.innerHTML = "";
  })
}

function calculateTotal(type,list)
{
  let sum=0;
  list.forEach(entry=>{
    if(entry.type == type){
      sum+=entry.amount;
    }

  })
  return sum;
}

function calculateBalance(Income,Outcome)
{
  return Income - Outcome;
}


function clearInput(inputs)
{
  inputs.forEach(input=> {
    input.value ="";
  })
}


function show(element){
  element.classList.remove("hide");
}

function hide(elements){
  elements.forEach(element => {
    element.classList.add("hide");
  })
}

function active(element){
  element.classList.remove("active");
}

function inactive(elements){
  elements.forEach(element => {
    element.classList.add("active");
  })
}

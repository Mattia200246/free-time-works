# Budget-App-JavaScript

​ @Code Explained  Says Hi

Today's project is the " Budget App" with vanilla JavaScript.

In this tutorial, a JavaScript beginner can be able to create a beautiful and functional budget app using JavaScript.
I will talk about the logic behind every line of code, before opening my text editor and start typing the code.
it's a step by step tutorial, you won't get lost at any stage of this tutorial.

Our app shows, the balance, the income and the outcome. it also has a dashboard where the user can add a new entry (an income or an expense), he can toggle between the income list (that show only all income entries) and the expenses list (that shows only the outcome entries) and all list that shows all the entries.
The user can edit or delete an entry.
Our app has a chart, so the user can easily compare the income and outcome.

The user's income and expense entry list is stored in the local storage, so when he refreshes the page, or reboot his machine, he can always find  his data there.

to follow the tutorial step by step, when we get to the second part (when we type the code), you'll need to download the starter template.

And then you can follow the tutorial on Youtube: https://youtu.be/SQbCwfGC7EM

When you open the folder, you'll find all the files needed to get started, the CSS code is already typed (see style.css file), as we're not going to talk about CSS in our tutorial. we're going just to talk about HTML and JavaScript.
